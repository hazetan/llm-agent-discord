# Shogi Front-End Game Design Notes

## Project Overview
Create an HTML-based front-end for a Shogi (Japanese chess) game using CSS and JS. CSS will be in a separate file from HTML.

## File Structure
```
index.html          # Main HTML page
style.css           # Separate CSS stylesheet
script.js           # JavaScript logic
design_notes.md     # This file
```

## Initial Design Decisions
- **Board Layout**: Classic 8x8 grid. Each square represents a shogi piece.
- **Pieces**: King (K), Rook (R), Bishop (B), Knight (N), Pawn (P). Represented by simple letters for now.
- **Game Flow**:
  - Player selects a piece and destination square via click.
  - Basic move validation: cannot move into own territory, cannot capture opponent's king, cannot move king to check.
  - Simple turn-based UI with "Your Move" and "Current Turn" indicators.
- **Styling**: Clean, responsive layout. CSS in separate `style.css`.
- **Scripts**: JavaScript in separate `script.js` handling board state, moves, checks.

## Action Log & Issues

### Step 1: Project Setup
- Created directory structure in Docker sandbox (empty initially).
- Wrote `design_notes.md` documenting the plan.
- No prior commands or existing files.

### Step 2: index.html
- Created minimal HTML skeleton:
  ```html
  <!DOCTYPE html>
  <html lang="ja">
  <head>
    <meta charset="UTF-8">
    <title>将棋ゲーム</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <h1>将棋 (Shogi)</h1>
    <div id="board"></div>
    <button id="restart">再プレイ</button>
    <script src="script.js"></script>
  </body>
  </html>
  ```
- Note: Board content is generated dynamically by JS; no static pieces.

### Step 3: style.css
- Created CSS stylesheet defining:
  - Body background and padding.
  - Grid layout for the board (`grid-template-columns/rows`, gap, border).
  - Square cells (`100px` size, flex center, cursor pointer).
  - Selected cell highlighting via `.selected` class.
  - Button styling.

### Step 4: script.js
- Created basic script that:
  - Creates 64 square divs on load.
  - Provides a "select square" mechanism via click.
  - Attempts to move piece from current source to target if adjacent.
  - Handles empty vs. occupied target (capture placeholder).
  - Includes restart functionality.

**Issues Encountered:**
- The initial move logic only handles moving to an adjacent cell and does not correctly manage piece ownership or capture. It also lacks proper removal of source element after move, leading to duplicate elements.
- No color differentiation between players (white/black) or piece types.
- No turn indicator displayed.
- The board recreation on restart is incomplete.

**Improvements Planned:**
- Implement proper capture: when target contains opponent's piece, remove it.
- Add piece colors (e.g., uppercase for white, lowercase for black) based on text content.
- Add turn switching after each move.
- Add simple check detection (not fully implemented but noted as roadblock).
- Add promotion (pawn -> queen) later.

## Potential Roadblocks & Solutions
1. **Capture Logic**: Need to detect opponent piece on target and clear it.
2. **Own Territory**: Prevent moving into squares occupied by own pieces.
3. **King Safety**: Detect check/mate – out of scope for MVP.
4. **Responsive Design**: Current CSS uses fixed 100px grid; may need media queries for larger screens.

## Improvements Planned
- [ ] Capture logic (check adjacent squares for opponent pieces).
- [ ] Castling rules (K+R move from corners).
- [ ] Move history / game over detection.
- [ ] Promote pawns to queen.
- [ ] Responsive layout adjustments.
- [ ] Turn indicator ("Your Move" / "Current Turn").

## Next Steps
- Refine `script.js` to handle moves correctly.
- Extend CSS with better visual cues (different colors per piece).
- Optionally add a simple game-over message when no legal moves remain.
